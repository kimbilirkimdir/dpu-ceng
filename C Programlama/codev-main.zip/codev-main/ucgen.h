#ifndef UCGEN

#define UCGEN

#include <int>

using namespace std;

class Author {

private:
    int k1;
    int k2;
    int k3;
    int k4;
    int cevre;
    int alan;

 

public:

   UCGEN(k1,k2,k3,k4,cevre,alan);

   int getk1() const;
   int getk2() const;
   int getk3() const;
   int getk4() const;
   int getcevre() const;
   int getalan() const; 
   
   void setk1(int k1);
   void setk2(int k2);
   void setk3(int k3);
   void setk4(int k4);
   void setcevre(int cevre);
   void setalan(int alan);
   void print() cevre;
   void print() alan;
   
};

 #endif
